#!/bin/bash

cd ~/Documents/AI/hw_2/wumpus-world-simulator

sum=0
for i in $(seq 1 12); do
   echo "\n\n###################"$i"\n"
   tmp="$(./pywumpsim -world worlds/world_$i.txt --tries 10)"
done
